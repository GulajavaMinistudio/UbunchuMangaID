Japanese-to-English translation by Anton Ekblad at https://groups.google.com/d/msg/ubunchu-translators/AN4H0WzFjQs/PhObHmJ5XlgJ (Thanks for your hard work!)
All pages were edited using GIMP
PDF was compiled using LibreOffice Impress
Font used is Ubuntu Medium
This is a basic translation job. Anything that goes beyond doing a whiteout on the chat bubbles are pretty much left as-is. This means that things like the cover page have been left untouched
